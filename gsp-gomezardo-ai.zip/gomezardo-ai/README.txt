GSP GOMEZARDO AI — versão inicial Android/navegador

O QUE INCLUI
- Interface adaptável a telemóveis Android, inspirada na imagem enviada.
- Avatar holográfico do robô usando avatar-gomezardo.png (PNG suportado; não procura .webp).
- Chat ligado à API OpenAI através de servidor Node (a chave fica no servidor).
- Voz: reconhecimento de voz e leitura de respostas, conforme suporte/permissões do navegador.
- Câmara, chamadas/SMS via aplicações do telemóvel, música local, pesquisa web, notas e temporizador.
- PWA básica para adicionar ao ecrã principal.

COMO INICIAR NUM COMPUTADOR
1. Instala Node.js 18 ou superior.
2. Extrai a pasta do ZIP.
3. Abre um terminal dentro da pasta gomezardo-ai.
4. Executa: npm install
5. Copia .env.example para .env e coloca a tua chave API em OPENAI_API_KEY.
6. Executa: npm start
7. Abre http://localhost:3000

IMPORTANTE
- A interface pode abrir sem chave API, mas o Chat IA só responde depois de configurar OPENAI_API_KEY no servidor.
- A chave API não deve ser colocada no HTML, app.js ou publicada no GitHub.
- A API pode ter custos conforme a conta e o uso.
- Câmara e microfone exigem permissões; em produção, normalmente exigem HTTPS. Localhost é aceite para testes.
- Chamadas e SMS apenas abrem o marcador/aplicação compatível; não fazem chamadas ou enviam SMS automaticamente.
- A pesquisa abre o Google; não é um motor de pesquisa próprio.
- Música toca ficheiros escolhidos no dispositivo.
- A imagem promocional fornecida está incluída como public/gsp-identidade.png.
