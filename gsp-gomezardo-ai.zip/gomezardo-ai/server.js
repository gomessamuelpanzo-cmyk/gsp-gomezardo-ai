require('dotenv').config();
const express = require('express');
const path = require('path');
const app = express();
app.use(express.json({ limit: '8mb' }));
app.use(express.static(path.join(__dirname, 'public')));

app.get('/api/status', (_req, res) => {
  res.json({ aiReady: Boolean(process.env.OPENAI_API_KEY), model: process.env.OPENAI_MODEL || 'gpt-6.2-astra' });
});

app.post('/api/chat', async (req, res) => {
  const key = process.env.OPENAI_API_KEY;
  if (!key || key === 'coloca_a_tua_chave_aqui') {
    return res.status(503).json({ error: 'A IA ainda não está ligada. Configura OPENAI_API_KEY no ficheiro .env do servidor.' });
  }
  const messages = Array.isArray(req.body.messages) ? req.body.messages.slice(-16) : [];
  if (!messages.length) return res.status(400).json({ error: 'Escreve uma mensagem primeiro.' });
  const input = messages.map(m => ({ role: m.role === 'assistant' ? 'assistant' : 'user', content: String(m.content || '').slice(0, 6000) }));
  try {
    const upstream = await fetch('https://api.openai.com/v1/responses', {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${key}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || 'gpt-6.2-astra',
        instructions: 'És o Gomezardo, assistente virtual do projeto GSP de Gomes Samuel Panzo. Fala sempre em português claro, preferencialmente português de Angola. Sê amigável, útil e honesto. Não afirmes que executaste ações que não executaste.',
        input,
        max_output_tokens: 900
      })
    });
    const data = await upstream.json();
    if (!upstream.ok) return res.status(upstream.status).json({ error: data.error?.message || 'A API de IA devolveu um erro.' });
    const answer = data.output_text || (data.output || []).flatMap(x => x.content || []).filter(x => x.type === 'output_text').map(x => x.text).join('\n');
    res.json({ answer: answer || 'Não consegui gerar uma resposta. Tenta novamente.' });
  } catch (err) {
    res.status(502).json({ error: 'Não foi possível contactar o serviço de IA. Verifica a ligação à Internet.' });
  }
});

app.get('*', (_req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));
const port = Number(process.env.PORT || 3000);
app.listen(port, '0.0.0.0', () => console.log(`GSP Gomezardo disponível em http://localhost:${port}`));
